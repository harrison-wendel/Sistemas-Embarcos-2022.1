#include <stdio.h>
#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/adc.h"
#include "esp_adc_cal.h"
#include <math.h>

#include "esp_system.h"
#include "driver/i2c.h"
#include "esp_log.h"
#include "sdkconfig.h"
#include "rom/uart.h"

#include "smbus.h"
#include "i2c-lcd1602.h"
#include <time.h>

#include <sntp.h>

#include <dht11.h>

const float BETA = 3950; // should match the Beta Coefficient of the thermistor

float SUP_LIM = 22.0;
float INF_LIM = 20.0;

#define DEC_INF_BTN GPIO_NUM_26
#define INC_INF_BTN GPIO_NUM_25
#define DEC_SUP_BTN GPIO_NUM_14
#define INC_SUP_BTN GPIO_NUM_12

#define MAX_TEMP 100.0
#define MIN_TEMP -100.0

#define TEMP_OK_LED GPIO_NUM_19
#define BAD_TEMP_LED GPIO_NUM_18

#define START_HEATER_BTN GPIO_NUM_4
#define START_COOLER_BTN GPIO_NUM_5

#define COOLER_EN_PIN GPIO_NUM_13
#define HEATER_EN_PIN GPIO_NUM_27

#define HEATING_LED GPIO_NUM_32
#define COOLING_LED GPIO_NUM_33

volatile bool dec_inf_btn_pressed = false;
volatile bool inc_inf_btn_pressed = false;
volatile bool dec_sup_btn_pressed = false;
volatile bool inc_sup_btn_pressed = false;

TaskHandle_t heating_led_handle, cooling_led_handle, notify_temp_to_telegram_handle;

static esp_adc_cal_characteristics_t adc1_chars;

i2c_lcd1602_info_t * lcd_info;

int heating, cooling;

int64_t timeA, timeB;

struct timeval tv_now;

  float temp;

time_t now;
  char strftime_buf[64];
  struct tm timeinfo;

char teleg_output[256];

time_t time1, time2;

// LCD1602
#define LCD_NUM_ROWS               2
#define LCD_NUM_COLUMNS            32
#define LCD_NUM_VISIBLE_COLUMNS    16

//#define USE_STDIN  1
#undef USE_STDIN

#define CONFIG_I2C_MASTER_SCL     GPIO_NUM_22
#define CONFIG_I2C_MASTER_SDA     GPIO_NUM_21
#define CONFIG_LCD1602_I2C_ADDRESS 0x27

#define I2C_MASTER_NUM           I2C_NUM_0
#define I2C_MASTER_TX_BUF_LEN    0                     // disabled
#define I2C_MASTER_RX_BUF_LEN    0                     // disabled
#define I2C_MASTER_FREQ_HZ       100000
#define I2C_MASTER_SDA_IO        CONFIG_I2C_MASTER_SDA
#define I2C_MASTER_SCL_IO        CONFIG_I2C_MASTER_SCL

#include <string.h>
#include <stdlib.h>
#include "nvs_flash.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "esp_tls.h"

#include "lwip/err.h"
#include "lwip/sys.h"
#include "esp_wifi.h"
#include "esp_http_client.h"
#include "freertos/event_groups.h"

/*HTTP buffer*/
#define MAX_HTTP_RECV_BUFFER 1024
#define MAX_HTTP_OUTPUT_BUFFER 2048

/* TAGs for the system*/
static const char *TAG = "HTTP_CLIENT Handler";
static const char *TAG1 = "wifi station";
static const char *TAG2 = "Sending getMe";
static const char *TAG3 = "Sending sendMessage";

/*WIFI configuration*/
#define ESP_WIFI_SSID      "W"
#define ESP_WIFI_PASS      "44724092"
#define ESP_MAXIMUM_RETRY  10

/*Telegram configuration*/
#define TOKEN_BOT "5719638774:AAGLGaNfy-5ozWqE6Dj14ivtawbgGDWow8w"
char url_string[512] = "https://api.telegram.org/bot";
// Using in the task 
// the main direct from the url will be in url_string
//The chat id that will receive the message
#define chat_ID1 "1683785028"
#define chat_ID2 "1683785028"

//Pin connected to a led
#define LED (GPIO_NUM_13)

/* FreeRTOS event group to signal when we are connected*/
static EventGroupHandle_t s_wifi_event_group;

/* The event group allows multiple bits for each event, but we only care about two events:
 * - we are connected to the AP with an IP
 * - we failed to connect after the maximum amount of retries */
#define WIFI_CONNECTED_BIT BIT0
#define WIFI_FAIL_BIT      BIT1

static int s_retry_num = 0;

extern const char telegram_certificate_pem_start[] asm("_binary_telegram_certificate_pem_start");
extern const char telegram_certificate_pem_end[]   asm("_binary_telegram_certificate_pem_end");

static void event_handler(void* arg, esp_event_base_t event_base,
                                int32_t event_id, void* event_data) {
    if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_START) {
        esp_wifi_connect();
    } else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_DISCONNECTED) {
        if (s_retry_num < ESP_MAXIMUM_RETRY) {
            esp_wifi_connect();
            s_retry_num++;
            ESP_LOGI(TAG1, "retry to connect to the AP");
        } else {
            xEventGroupSetBits(s_wifi_event_group, WIFI_FAIL_BIT);
        }
        ESP_LOGI(TAG1,"connect to the AP fail");
    } else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t* event = (ip_event_got_ip_t*) event_data;
        ESP_LOGI(TAG1, "got ip:" IPSTR, IP2STR(&event->ip_info.ip));
        s_retry_num = 0;
        xEventGroupSetBits(s_wifi_event_group, WIFI_CONNECTED_BIT);
    }
}

void wifi_init_sta(void) {
    s_wifi_event_group = xEventGroupCreate();

    ESP_ERROR_CHECK(esp_netif_init());

    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    esp_event_handler_instance_t instance_any_id;
    esp_event_handler_instance_t instance_got_ip;
    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT,
                                                        ESP_EVENT_ANY_ID,
                                                        &event_handler,
                                                        NULL,
                                                        &instance_any_id));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(IP_EVENT,
                                                        IP_EVENT_STA_GOT_IP,
                                                        &event_handler,
                                                        NULL,
                                                        &instance_got_ip));

    wifi_config_t wifi_config = {
        .sta = {
            .ssid = ESP_WIFI_SSID,
            .password = ESP_WIFI_PASS,
            /* Setting a password implies station will connect to all security modes including WEP/WPA.
             * However these modes are deprecated and not advisable to be used. Incase your Access point
             * doesn't support WPA2, these mode can be enabled by commenting below line */
	     .threshold.authmode = WIFI_AUTH_WPA2_PSK,

            .pmf_cfg = {
                .capable = true,
                .required = false
            },
        },
    };
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA) );
    ESP_ERROR_CHECK(esp_wifi_set_config(ESP_IF_WIFI_STA, &wifi_config) );
    ESP_ERROR_CHECK(esp_wifi_start() );

    ESP_LOGI(TAG1, "wifi_init_sta finished.");

    /* Waiting until either the connection is established (WIFI_CONNECTED_BIT) or connection failed for the maximum
     * number of re-tries (WIFI_FAIL_BIT). The bits are set by event_handler() (see above) */
    EventBits_t bits = xEventGroupWaitBits(s_wifi_event_group,
            WIFI_CONNECTED_BIT | WIFI_FAIL_BIT,
            pdFALSE,
            pdFALSE,
            portMAX_DELAY);

    /* xEventGroupWaitBits() returns the bits before the call returned, hence we can test which event actually
     * happened. */
    if (bits & WIFI_CONNECTED_BIT) {
        ESP_LOGI(TAG1, "connected to ap SSID:%s password:%s",
                 ESP_WIFI_SSID, ESP_WIFI_PASS);
    } else if (bits & WIFI_FAIL_BIT) {
        ESP_LOGI(TAG1, "Failed to connect to SSID:%s, password:%s",
                 ESP_WIFI_SSID, ESP_WIFI_PASS);
    } else {
        ESP_LOGE(TAG1, "UNEXPECTED EVENT");
    }

    /* The event will not be processed after unregister */
    ESP_ERROR_CHECK(esp_event_handler_instance_unregister(IP_EVENT, IP_EVENT_STA_GOT_IP, instance_got_ip));
    ESP_ERROR_CHECK(esp_event_handler_instance_unregister(WIFI_EVENT, ESP_EVENT_ANY_ID, instance_any_id));
    vEventGroupDelete(s_wifi_event_group);
}


esp_err_t _http_event_handler(esp_http_client_event_t *evt) {
    static char *output_buffer;  // Buffer to store response of http request from event handler
    static int output_len;       // Stores number of bytes read
    switch(evt->event_id) {
        case HTTP_EVENT_ERROR:
            ESP_LOGD(TAG, "HTTP_EVENT_ERROR");
            break;
        case HTTP_EVENT_ON_CONNECTED:
            ESP_LOGD(TAG, "HTTP_EVENT_ON_CONNECTED");
            break;
        case HTTP_EVENT_HEADER_SENT:
            ESP_LOGD(TAG, "HTTP_EVENT_HEADER_SENT");
            break;
        case HTTP_EVENT_ON_HEADER:
            ESP_LOGD(TAG, "HTTP_EVENT_ON_HEADER, key=%s, value=%s", evt->header_key, evt->header_value);
            break;
        case HTTP_EVENT_ON_DATA:
            ESP_LOGD(TAG, "HTTP_EVENT_ON_DATA, len=%d", evt->data_len);
            /*
             *  Check for chunked encoding is added as the URL for chunked encoding used in this example returns binary data.
             *  However, event handler can also be used in case chunked encoding is used.
             */
            if (!esp_http_client_is_chunked_response(evt->client)) {
                // If user_data buffer is configured, copy the response into the buffer
                if (evt->user_data) {
                    memcpy(evt->user_data + output_len, evt->data, evt->data_len);
                } else {
                    if (output_buffer == NULL) {
                        output_buffer = (char *) malloc(esp_http_client_get_content_length(evt->client));
                        output_len = 0;
                        if (output_buffer == NULL) {
                            ESP_LOGE(TAG, "Failed to allocate memory for output buffer");
                            return ESP_FAIL;
                        }
                    }
                    memcpy(output_buffer + output_len, evt->data, evt->data_len);
                }
                output_len += evt->data_len;
            }

            break;
        case HTTP_EVENT_ON_FINISH:
            ESP_LOGD(TAG, "HTTP_EVENT_ON_FINISH");
            if (output_buffer != NULL) {
                // Response is accumulated in output_buffer. Uncomment the below line to print the accumulated response
                // ESP_LOG_BUFFER_HEX(TAG, output_buffer, output_len);
                free(output_buffer);
                output_buffer = NULL;
            }
            output_len = 0;
            break;
        case HTTP_EVENT_DISCONNECTED:
            ESP_LOGI(TAG, "HTTP_EVENT_DISCONNECTED");
            int mbedtls_err = 0;
            esp_err_t err = esp_tls_get_and_clear_last_error(evt->data, &mbedtls_err, NULL);
            if (err != 0) {
                if (output_buffer != NULL) {
                    free(output_buffer);
                    output_buffer = NULL;
                }
                output_len = 0;
                ESP_LOGI(TAG, "Last esp error code: 0x%x", err);
                ESP_LOGI(TAG, "Last mbedtls failure: 0x%x", mbedtls_err);
            }
            break;
    }
    return ESP_OK;
}


/*
 *  http_native_request() demonstrates use of low level APIs to connect to a server,
 *  make a http request and read response. Event handler is not used in this case.
 *  Note: This approach should only be used in case use of low level APIs is required.
 *  The easiest way is to use esp_http_perform()
 */
static void http_native_request(void) {
    char output_buffer[MAX_HTTP_OUTPUT_BUFFER] = "";   // Buffer to store response of http request
    int content_length = 0;
    esp_http_client_config_t config = {
        .url = "http://httpbin.org/get",
    };
    esp_http_client_handle_t client = esp_http_client_init(&config);

    // GET Request
    esp_http_client_set_method(client, HTTP_METHOD_GET);
    esp_err_t err = esp_http_client_open(client, 0);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to open HTTP connection: %s", esp_err_to_name(err));
    } else {
        content_length = esp_http_client_fetch_headers(client);
        if (content_length < 0) {
            ESP_LOGE(TAG, "HTTP client fetch headers failed");
        } else {
            int data_read = esp_http_client_read_response(client, output_buffer, MAX_HTTP_OUTPUT_BUFFER);
            if (data_read >= 0) {
                ESP_LOGI(TAG, "HTTP GET Status = %d, content_length = %d",
                esp_http_client_get_status_code(client),
                esp_http_client_get_content_length(client));
                //ESP_LOG_BUFFER_HEX(TAG, output_buffer, strlen(output_buffer));
                for(int i = 0; i < esp_http_client_get_content_length(client); i++) {
                    putchar(output_buffer[i]);
                }
                putchar('\r');
                putchar('\n');
            } else {
                ESP_LOGE(TAG, "Failed to read response");
            }
        }
    }
    esp_http_client_close(client);

    // POST Request
    const char *post_data = "{\"field1\":\"value1\"}";
    esp_http_client_set_url(client, "http://httpbin.org/post");
    esp_http_client_set_method(client, HTTP_METHOD_POST);
    esp_http_client_set_header(client, "Content-Type", "application/json");
    err = esp_http_client_open(client, strlen(post_data));
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to open HTTP connection: %s", esp_err_to_name(err));
    } else {
        int wlen = esp_http_client_write(client, post_data, strlen(post_data));
        if (wlen < 0) {
            ESP_LOGE(TAG, "Write failed");
        }
        int data_read = esp_http_client_read_response(client, output_buffer, MAX_HTTP_OUTPUT_BUFFER);
        if (data_read >= 0) {
            ESP_LOGI(TAG, "HTTP GET Status = %d, content_length = %d",
            esp_http_client_get_status_code(client),
            esp_http_client_get_content_length(client));
            //ESP_LOG_BUFFER_HEX(TAG, output_buffer, strlen(output_buffer));
            for(int i = 0; i < esp_http_client_get_content_length(client); i++) {
                putchar(output_buffer[i]);
            }
            putchar('\r');
            putchar('\n');
        } else {
            ESP_LOGE(TAG, "Failed to read response");
        }
    }
    esp_http_client_cleanup(client);
}


static void https_telegram_getMe_perform(void) {
	char buffer[MAX_HTTP_OUTPUT_BUFFER] = {0};   // Buffer to store response of http request
	char url[512] = "";
    esp_http_client_config_t config = {
        .url = "https://api.telegram.org",
        .transport_type = HTTP_TRANSPORT_OVER_SSL,
        .event_handler = _http_event_handler,
        .cert_pem = telegram_certificate_pem_start,
        .user_data = buffer,        // Pass address of local buffer to get response
    };
    /* Creating the string of the url*/
    //Copy the url+TOKEN
    strcat(url,url_string);
    //Adding the method
    strcat(url,"/getMe");
    //ESP_LOGW(TAG2, "url es: %s",url);
    //ESP_LOGW(TAG, "Iniciare");
    esp_http_client_handle_t client = esp_http_client_init(&config);
    //You set the real url for the request
    esp_http_client_set_url(client, url);
    //ESP_LOGW(TAG, "Selecting the http method");
    esp_http_client_set_method(client, HTTP_METHOD_GET);
    //ESP_LOGW(TAG, "Perform");
    esp_err_t err = esp_http_client_perform(client);

    //ESP_LOGW(TAG, "Revisare");
    if (err == ESP_OK) {
        ESP_LOGI(TAG2, "HTTPS Status = %d, content_length = %d",
                esp_http_client_get_status_code(client),
                esp_http_client_get_content_length(client));
        ESP_LOGW(TAG2, "Desde Perform el output es: %s",buffer);
    } else {
        ESP_LOGE(TAG2, "Error perform http request %s", esp_err_to_name(err));
    }

    ESP_LOGW(TAG2, "Cerrar Cliente");
    esp_http_client_close(client);
    ESP_LOGW(TAG, "Limpiare");
    esp_http_client_cleanup(client);
}

static void https_telegram_getMe_native_get(void) {

	/*	Partiendo de http_native_request
	 *  http_native_request() demonstrates use of low level APIs to connect to a server,
	 *  make a http request and read response. Event handler is not used in this case.
	 *  Note: This approach should only be used in case use of low level APIs is required.
	 *  The easiest way is to use esp_http_perform()
	 */

    char output_buffer[MAX_HTTP_OUTPUT_BUFFER] = {0};   // Buffer to store response of http request
    int content_length = 0;
    char url[512] = "";
    esp_http_client_config_t config = {
        .url = "https://api.telegram.org",
        .transport_type = HTTP_TRANSPORT_OVER_SSL,
        .event_handler = _http_event_handler,
        .cert_pem = telegram_certificate_pem_start,
    };
    ESP_LOGW(TAG2, "Iniciare 2");
    esp_http_client_handle_t client = esp_http_client_init(&config);

    // GET Request
    ESP_LOGW(TAG2, "Method");
    esp_http_client_set_method(client, HTTP_METHOD_GET);
    ESP_LOGW(TAG2, "Open");
    /* Creating the string of the url*/
    //Copy the url+TOKEN
    strcat(url,url_string);
    //Adding the method
    strcat(url,"/getMe");
    //ESP_LOGW(TAG2, "url string es: %s",url);
    //You set the real url for the request
    esp_http_client_set_url(client, url);
    esp_err_t err = esp_http_client_open(client, 0);
    if (err != ESP_OK) {
        ESP_LOGE(TAG2, "Failed to open HTTP connection: %s", esp_err_to_name(err));
    } else {
        ESP_LOGW(TAG2, "Fetch");
        content_length = esp_http_client_fetch_headers(client);
        if (content_length < 0) {
            ESP_LOGE(TAG2, "HTTP client fetch headers failed");
        } else {
            ESP_LOGW(TAG2, "Response");
            int data_read = esp_http_client_read_response(client, output_buffer, MAX_HTTP_OUTPUT_BUFFER);
            if (data_read >= 0) {
                ESP_LOGI(TAG, "HTTP GET Status = %d, content_length = %d",
                esp_http_client_get_status_code(client),
                esp_http_client_get_content_length(client));
                //ESP_LOG_BUFFER_CHAR(TAG2, output_buffer, strlen(output_buffer));
            //    ESP_LOG_BUFFER_HEX(TAG2, output_buffer, strlen(output_buffer));
                for(int i = 0; i < esp_http_client_get_content_length(client); i++) {
                    putchar(output_buffer[i]);
                }
                putchar('\r');
                putchar('\n');
            } else {
                ESP_LOGE(TAG2, "Failed to read response");
            }
        }
    }
    ESP_LOGW(TAG2, "Cerrar Cliente");
    esp_http_client_close(client);
    esp_http_client_cleanup(client);
    ESP_LOGI(TAG2, "Desde perform esp_get_free_heap_size: %d", esp_get_free_heap_size ());
}

static void https_telegram_sendMessage_native_get(void) {


	/* Format for sending messages
	https://api.telegram.org/bot[BOT_TOKEN]/sendMessage?chat_id=[CHANNEL_NAME]&text=[MESSAGE_TEXT]
	For public groups you can use
	https://api.telegram.org/bot[BOT_TOKEN]/sendMessage?chat_id=@GroupName&text=hello%20world
	For private groups you have to use the chat id (which also works with public groups)
	https://api.telegram.org/bot[BOT_TOKEN]/sendMessage?chat_id=-1234567890123&text=hello%20world
	You can add your chat_id or group name, your api key and use your browser to send those messages
	The %20 is the hexa for the space
	*/

    char output_buffer[MAX_HTTP_OUTPUT_BUFFER] = {0};   // Buffer to store response of http request
    int content_length = 0;
    char url[512] = "";
    esp_http_client_config_t config = {
        .url = "https://api.telegram.org",
        .transport_type = HTTP_TRANSPORT_OVER_SSL,
        .event_handler = _http_event_handler,
        .cert_pem = telegram_certificate_pem_start,
    };

    ESP_LOGW(TAG3, "Iniciare");
    esp_http_client_handle_t client = esp_http_client_init(&config);
    ESP_LOGW(TAG3, "Enviare un mensaje a un chat");
    ESP_LOGW(TAG3, "Open");
    /* Creating the string of the url*/
    //Copy the url+TOKEN
    strcat(url,url_string);
    //Then you concatenate the method with the information
    strcat(url,"/sendMessage?chat_id=");
    strcat(url,chat_ID1);
    /* Now you add the text*/
    strcat(url,"&text=");
    //Between every word you have to put %20 for the space (maybe there is another way for this)
    strcat(url,"Text%20to%20send%20to%20the%20chat");
    ESP_LOGW(TAG3, "url string es: %s",url);
    //You set the real url for the request
    esp_http_client_set_url(client, url);

    esp_err_t err = esp_http_client_open(client, 0);
    if (err != ESP_OK) {
        ESP_LOGE(TAG3, "Failed to open HTTP connection: %s", esp_err_to_name(err));
    } else {
        ESP_LOGW(TAG3, "Fetch 2");
        content_length = esp_http_client_fetch_headers(client);
        if (content_length < 0) {
            ESP_LOGE(TAG3, "HTTP client fetch headers failed");
        } else {
            ESP_LOGW(TAG3, "Response 2");
            int data_read = esp_http_client_read_response(client, output_buffer, MAX_HTTP_OUTPUT_BUFFER);
            if (data_read >= 0) {
                ESP_LOGI(TAG, "HTTP GET Status = %d, content_length = %d",
                esp_http_client_get_status_code(client),
                esp_http_client_get_content_length(client));
                //ESP_LOG_BUFFER_CHAR(TAG2, output_buffer, 188);
                //ESP_LOG_BUFFER_HEX(TAG2, output_buffer, strlen(output_buffer));
                for(int i = 0; i < esp_http_client_get_content_length(client); i++) {
                    putchar(output_buffer[i]);
                }
                putchar('\r');
                putchar('\n');
            } else {
                ESP_LOGE(TAG3, "Failed to read response");
            }
        }
    }
    ESP_LOGW(TAG, "Limpiare");
    esp_http_client_close(client);
    esp_http_client_cleanup(client);
    ESP_LOGI(TAG, "esp_get_free_heap_size: %d", esp_get_free_heap_size ());
}

static void https_telegram_sendMessage_perform_post(void *pvParameters) {


	/* Format for sending messages
	https://api.telegram.org/bot[BOT_TOKEN]/sendMessage?chat_id=[CHANNEL_NAME]&text=[MESSAGE_TEXT]
	For public groups you can use
	https://api.telegram.org/bot[BOT_TOKEN]/sendMessage?chat_id=@GroupName&text=hello%20world
	For private groups you have to use the chat id (which also works with public groups)
	https://api.telegram.org/bot[BOT_TOKEN]/sendMessage?chat_id=-1234567890123&text=hello%20world
	You can add your chat_id or group name, your api key and use your browser to send those messages
	The %20 is the hexa for the space
	The format for the json is: {"chat_id":852596694,"text":"Message using post"}
	*/

	char url[512] = "";
    char output_buffer[MAX_HTTP_OUTPUT_BUFFER] = {0};   // Buffer to store response of http request
    esp_http_client_config_t config = {
        .url = "https://api.telegram.org",
        .transport_type = HTTP_TRANSPORT_OVER_SSL,
        .event_handler = _http_event_handler,
        .cert_pem = telegram_certificate_pem_start,
		.user_data = output_buffer,
    };
    //POST
    ESP_LOGW(TAG3, "Iniciare");
    esp_http_client_handle_t client = esp_http_client_init(&config);

    /* Creating the string of the url*/
    //Copy the url+TOKEN
    strcat(url,url_string);
    //Passing the method
    strcat(url,"/sendMessage");
    ESP_LOGW(TAG3, "url string es: %s",url);
    //You set the real url for the request
    esp_http_client_set_url(client, url);


	ESP_LOGW(TAG3, "Enviare POST");
	/*Here you add the text and the chat id
	 * The format for the json for the telegram request is: {"chat_id":123456789,"text":"Here goes the message"}
	  */
	// The example had this, but to add the chat id easierly I decided not to use a pointer
	//const char *post_data = "{\"chat_id\":852596694,\"text\":\"Envio de post\"}";
	char post_data[512] = "";
	sprintf(post_data,"{\"chat_id\":%s,\"text\":\"%s\"}",chat_ID2, (char*) pvParameters);
    ESP_LOGW(TAG, "El json es es: %s",post_data);
    esp_http_client_set_method(client, HTTP_METHOD_POST);
    esp_http_client_set_header(client, "Content-Type", "application/json");
    esp_http_client_set_post_field(client, post_data, strlen(post_data));

    esp_err_t err = esp_http_client_perform(client);
    if (err == ESP_OK) {
        ESP_LOGI(TAG3, "HTTP POST Status = %d, content_length = %d",
                esp_http_client_get_status_code(client),
                esp_http_client_get_content_length(client));
        ESP_LOGW(TAG3, "Desde Perform el output es: %s",output_buffer);

    } else {
        ESP_LOGE(TAG3, "HTTP POST request failed: %s", esp_err_to_name(err));
    }

    ESP_LOGW(TAG, "Limpiare");
    esp_http_client_close(client);
    esp_http_client_cleanup(client);
    ESP_LOGI(TAG3, "esp_get_free_heap_size: %d", esp_get_free_heap_size ());
}


static void http_test_task(void *pvParameters) {
    /* Creating the string of the url*/
    // You concatenate the host with the Token so you only have to write the method
	//strcat(url_string,TOKEN);
    ESP_LOGW(TAG, "Wait 2 second before start");
    //vTaskDelay(2000 / portTICK_PERIOD_MS);

    //ESP_LOGW(TAG, "https_telegram_getMe_perform");
    //https_telegram_getMe_perform();
    /* The functions https_telegram_getMe_native_get and https_telegram_sendMessage_native_get usually reboot the esp32 at when you use it after another and
     *  the second one finish, but I don't know why. Either way, it still send the message and obtain the getMe response, but the perform way is better
     *  for both options, especially for sending message with Json.*/
    //ESP_LOGW(TAG, "https_telegram_getMe_native_get");
    //https_telegram_getMe_native_get();
    //ESP_LOGW(TAG, "https_telegram_sendMessage_native_get");
    //https_telegram_sendMessage_native_get();
    ESP_LOGW(TAG, "https_telegram_sendMessage_perform_post");
    https_telegram_sendMessage_perform_post(pvParameters);

    ESP_LOGI(TAG, "Finish http example");
    vTaskDelete(NULL);
}



static void i2c_master_init(void)
{
    int i2c_master_port = I2C_MASTER_NUM;
    i2c_config_t conf;
    conf.mode = I2C_MODE_MASTER;
    conf.sda_io_num = I2C_MASTER_SDA_IO;
    conf.sda_pullup_en = GPIO_PULLUP_DISABLE;  // GY-2561 provides 10kΩ pullups
    conf.scl_io_num = I2C_MASTER_SCL_IO;
    conf.scl_pullup_en = GPIO_PULLUP_DISABLE;  // GY-2561 provides 10kΩ pullups
    conf.master.clk_speed = I2C_MASTER_FREQ_HZ;
    i2c_param_config(i2c_master_port, &conf);
    i2c_driver_install(i2c_master_port, conf.mode,
                       I2C_MASTER_RX_BUF_LEN,
                       I2C_MASTER_TX_BUF_LEN, 0);
}

void config_temp_sensor(){
    gpio_reset_pin(GPIO_NUM_23);
    gpio_set_direction(GPIO_NUM_23, GPIO_MODE_INPUT);
    gpio_pullup_en(GPIO_NUM_23);
    DHT11_init(GPIO_NUM_23);
}

float read_temp() {
  //float voltage;
  //float celsius;
  //voltage = esp_adc_cal_raw_to_voltage(adc1_get_raw(ADC1_CHANNEL_6), &adc1_chars);
  //celsius = 1.0 / (log(1.0 / (1023.0 / voltage - 1.0)) / BETA + 1.0 / 298.15) - 273.15;
  //return celsius;
  return (float)DHT11_read().temperature;
}

void config_ext_display(void * pvParameter){
    // Set up I2C
    i2c_master_init();
    i2c_port_t i2c_num = I2C_MASTER_NUM;
    uint8_t address = CONFIG_LCD1602_I2C_ADDRESS;

    // Set up the SMBus
    smbus_info_t * smbus_info = smbus_malloc();
    ESP_ERROR_CHECK(smbus_init(smbus_info, i2c_num, address));
    ESP_ERROR_CHECK(smbus_set_timeout(smbus_info, 1000 / portTICK_RATE_MS));

    // Set up the LCD1602 device with backlight off
    lcd_info = i2c_lcd1602_malloc();
    ESP_ERROR_CHECK(i2c_lcd1602_init(lcd_info, smbus_info, true,
                                     LCD_NUM_ROWS, LCD_NUM_COLUMNS, LCD_NUM_VISIBLE_COLUMNS));

    ESP_ERROR_CHECK(i2c_lcd1602_reset(lcd_info));

    vTaskDelete(NULL);

}

void write_on_display(char* text, int line) {
  i2c_lcd1602_move_cursor(lcd_info, 0, line);
  i2c_lcd1602_write_string(lcd_info, text);
}
/*
if (dec_inf_btn_pressed) {
      if (INF_LIM - 0.1 >= MIN_TEMP) INF_LIM = INF_LIM - 0.1;
      dec_inf_btn_pressed = false;
    }
    if (inc_inf_btn_pressed) {
      if (INF_LIM + 0.1 < SUP_LIM) INF_LIM = INF_LIM + 0.1;
      inc_inf_btn_pressed = false;
    } 
    if (dec_sup_btn_pressed) {
      if (SUP_LIM - 0.1 > INF_LIM) SUP_LIM = SUP_LIM - 0.1;
      dec_sup_btn_pressed = false;
    }
    if (inc_sup_btn_pressed) {
      if (SUP_LIM + 0.1 <= MAX_TEMP) SUP_LIM = SUP_LIM + 0.1;
      inc_sup_btn_pressed = false;
    }
*/
static void gpio_isr_dec_inf_btn_handler(void* arg)
{
    gettimeofday(&tv_now, NULL);
    time1 = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
    time2 = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
    while (time2 - time1 < 50000){
        vTaskDelay(5 / portTICK_PERIOD_MS);
        gettimeofday(&tv_now, NULL);
        time2 = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
    }
    if (!gpio_get_level(DEC_INF_BTN) && INF_LIM - 0.1 >= MIN_TEMP) INF_LIM = INF_LIM - 0.1;
    //dec_inf_btn_pressed = true;
}

static void gpio_isr_inc_inf_btn_handler(void* arg)
{
    gettimeofday(&tv_now, NULL);
    time1 = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
    time2 = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
    while (time2 - time1 < 50000){
        vTaskDelay(5 / portTICK_PERIOD_MS);
        gettimeofday(&tv_now, NULL);
        time2 = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
    }
    if (!gpio_get_level(INC_INF_BTN) && INF_LIM + 0.1 < SUP_LIM) INF_LIM = INF_LIM + 0.1;
    //inc_inf_btn_pressed = true;
}

static void gpio_isr_dec_sup_btn_handler(void* arg)
{
    gettimeofday(&tv_now, NULL);
    time1 = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
    time2 = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
    while (time2 - time1 < 50000){
        vTaskDelay(5 / portTICK_PERIOD_MS);
        gettimeofday(&tv_now, NULL);
        time2 = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
    }
    if (!gpio_get_level(DEC_SUP_BTN) && SUP_LIM - 0.1 > INF_LIM) SUP_LIM = SUP_LIM - 0.1;
    //dec_sup_btn_pressed = true;
}

static void gpio_isr_inc_sup_btn_handler(void* arg)
{
    gettimeofday(&tv_now, NULL);
    time1 = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
    time2 = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
    while (time2 - time1 < 50000){
        vTaskDelay(5 / portTICK_PERIOD_MS);
        gettimeofday(&tv_now, NULL);
        time2 = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
    }
    if (!gpio_get_level(INC_SUP_BTN) && SUP_LIM + 0.1 <= MAX_TEMP) SUP_LIM = SUP_LIM + 0.1;
    //inc_sup_btn_pressed = true;
}


void config_dec_inf_btn()
{
    //gpio_install_isr_service(0);
    //printf("configuring button\n");
    gpio_reset_pin(DEC_INF_BTN);
    gpio_set_direction(DEC_INF_BTN, GPIO_MODE_INPUT);
    gpio_pullup_en(DEC_INF_BTN);
    gpio_set_intr_type(DEC_INF_BTN, GPIO_INTR_NEGEDGE);
    gpio_isr_handler_add(DEC_INF_BTN, gpio_isr_dec_inf_btn_handler, NULL);
    //printf("config complete\n");
}

void config_dec_sup_btn()
{
   // gpio_install_isr_service(0);
    //printf("configuring button\n");
    gpio_reset_pin(DEC_SUP_BTN);
    gpio_set_direction(DEC_SUP_BTN, GPIO_MODE_INPUT);
    gpio_pullup_en(DEC_SUP_BTN);
    gpio_set_intr_type(DEC_SUP_BTN, GPIO_INTR_NEGEDGE);
    gpio_isr_handler_add(DEC_SUP_BTN, gpio_isr_dec_sup_btn_handler, NULL);
    //printf("config complete\n");
}

void config_inc_inf_btn()
{
    //gpio_install_isr_service(0);
    //printf("configuring button\n");
    gpio_reset_pin(INC_INF_BTN);
    gpio_set_direction(INC_INF_BTN, GPIO_MODE_INPUT);
    gpio_pullup_en(INC_INF_BTN);
    gpio_set_intr_type(INC_INF_BTN, GPIO_INTR_NEGEDGE);
    gpio_isr_handler_add(INC_INF_BTN, gpio_isr_inc_inf_btn_handler, NULL);
    //printf("config complete\n");
}

void config_inc_sup_btn()
{
    //gpio_install_isr_service(0);
    //printf("configuring button\n");
    gpio_reset_pin(INC_SUP_BTN);
    gpio_set_direction(INC_SUP_BTN, GPIO_MODE_INPUT);
    gpio_pullup_en(INC_SUP_BTN);
    gpio_set_intr_type(INC_SUP_BTN, GPIO_INTR_NEGEDGE);
    gpio_isr_handler_add(INC_SUP_BTN, gpio_isr_inc_sup_btn_handler, NULL);
    //printf("config complete\n");
}

void config_ok_temp_led(){
    gpio_reset_pin(TEMP_OK_LED);
    gpio_set_direction(TEMP_OK_LED, GPIO_MODE_OUTPUT);
}

void config_bad_temp_led(){
    gpio_reset_pin(BAD_TEMP_LED);
    gpio_set_direction(BAD_TEMP_LED, GPIO_MODE_OUTPUT);
}

void config_heating_led(){
  gpio_reset_pin(HEATING_LED);
  gpio_set_direction(HEATING_LED, GPIO_MODE_OUTPUT);
}

void config_cooling_led(){
  gpio_reset_pin(COOLING_LED);
  gpio_set_direction(COOLING_LED, GPIO_MODE_OUTPUT);
}

void config_heater_en_pin(){
  gpio_reset_pin(HEATER_EN_PIN);
  gpio_set_direction(HEATER_EN_PIN, GPIO_MODE_OUTPUT);
  gpio_set_level(HEATER_EN_PIN, 1);
}

void config_cooler_en_pin(){
  gpio_reset_pin(COOLER_EN_PIN);
  gpio_set_direction(COOLER_EN_PIN, GPIO_MODE_OUTPUT);
  gpio_set_level(COOLER_EN_PIN, 1);
}

void blink_bad_temp_led(void * pvParameter){
  while (1){
      gpio_set_level(BAD_TEMP_LED, 0);
      vTaskDelay(100 / portTICK_PERIOD_MS);
      gpio_set_level(BAD_TEMP_LED, 1);
      vTaskDelay(100 / portTICK_PERIOD_MS);
  }
}

void blink_heating_led(void * pvParameter){
  while (1){
      gpio_set_level(HEATING_LED, 0);
      vTaskDelay(100 / portTICK_PERIOD_MS);
      gpio_set_level(HEATING_LED, 1);
      vTaskDelay(100 / portTICK_PERIOD_MS);
  }
}

void blink_cooling_led(void * pvParameter){
  while (1){
      gpio_set_level(COOLING_LED, 0);
      vTaskDelay(100 / portTICK_PERIOD_MS);
      gpio_set_level(COOLING_LED, 1);
      vTaskDelay(100 / portTICK_PERIOD_MS);
  }
}

void start_heater(){
    if (heating || cooling)
    return;
  gettimeofday(&tv_now, NULL);
  timeA = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
  heating = 1;
  gpio_set_level(HEATER_EN_PIN, 0);
  vTaskResume( heating_led_handle );
          memset(teleg_output,0,sizeof(teleg_output));
        time(&now);
        localtime_r(&now, &timeinfo);
        strftime(strftime_buf, sizeof(strftime_buf), "%c", &timeinfo);
        sprintf(teleg_output, "Heater started at %s", strftime_buf);
        xTaskCreatePinnedToCore(&http_test_task, "http_test_task", 8192*4, teleg_output, 5, NULL,1);
}

void start_cooler(){
    if (heating || cooling)
    return;
  gettimeofday(&tv_now, NULL);
  gpio_set_level(COOLER_EN_PIN, 0);
  timeA = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
  cooling = 1;
  vTaskResume( cooling_led_handle );
  memset(teleg_output,0,sizeof(teleg_output));
        time(&now);
        localtime_r(&now, &timeinfo);
        strftime(strftime_buf, sizeof(strftime_buf), "%c", &timeinfo);
        sprintf(teleg_output, "Cooler started at %s", strftime_buf);
        xTaskCreatePinnedToCore(&http_test_task, "http_test_task", 8192*4, teleg_output, 5, NULL,1);
}

void stop_heater(){
  heating = 0;
  gpio_set_level(HEATER_EN_PIN, 1);
  vTaskSuspend( heating_led_handle );
  vTaskDelay(20 / portTICK_PERIOD_MS);
  gpio_set_level(HEATING_LED, 0);
  memset(teleg_output,0,sizeof(teleg_output));
            time(&now);
            localtime_r(&now, &timeinfo);
            strftime(strftime_buf, sizeof(strftime_buf), "%c", &timeinfo);
            sprintf(teleg_output, "Heater stopped at %s", strftime_buf);
            xTaskCreatePinnedToCore(&http_test_task, "http_test_task", 8192*4, teleg_output, 5, NULL,1);
}

void stop_cooler(){
  cooling = 0;
  gpio_set_level(COOLER_EN_PIN, 1);
  vTaskSuspend( cooling_led_handle );
  vTaskDelay(20 / portTICK_PERIOD_MS);
  gpio_set_level(COOLING_LED, 0);
  memset(teleg_output,0,sizeof(teleg_output));
            time(&now);
            localtime_r(&now, &timeinfo);
            strftime(strftime_buf, sizeof(strftime_buf), "%c", &timeinfo);
            sprintf(teleg_output, "Cooler stopped at %s", strftime_buf);
            xTaskCreatePinnedToCore(&http_test_task, "http_test_task", 8192*4, teleg_output, 5, NULL,1);
}

static void gpio_isr_start_cooler_btn_handler(void* arg)
{
    gettimeofday(&tv_now, NULL);
    time1 = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
    time2 = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
    while (time2 - time1 < 50000){
        vTaskDelay(5 / portTICK_PERIOD_MS);
        gettimeofday(&tv_now, NULL);
        time2 = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
    }
    if (!gpio_get_level(START_COOLER_BTN))
      start_cooler();
}

static void gpio_isr_start_heater_btn_handler(void* arg)
{   
    gettimeofday(&tv_now, NULL);
    time1 = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
    time2 = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
    while (time2 - time1 < 50000){
        vTaskDelay(5 / portTICK_PERIOD_MS);
        gettimeofday(&tv_now, NULL);
        time2 = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
    }
    if (!gpio_get_level(START_HEATER_BTN))
        start_heater();
}

void config_start_heater_btn(){
    gpio_reset_pin(START_HEATER_BTN);
    gpio_set_direction(START_HEATER_BTN, GPIO_MODE_INPUT);
    gpio_pullup_en(START_HEATER_BTN);
    gpio_set_intr_type(START_HEATER_BTN, GPIO_INTR_NEGEDGE);
    gpio_isr_handler_add(START_HEATER_BTN, gpio_isr_start_heater_btn_handler, NULL);
}

void config_start_cooler_btn(){
    gpio_reset_pin(START_COOLER_BTN);
    gpio_set_direction(START_COOLER_BTN, GPIO_MODE_INPUT);
    gpio_pullup_en(START_COOLER_BTN);
    gpio_set_intr_type(START_COOLER_BTN, GPIO_INTR_NEGEDGE);
    gpio_isr_handler_add(START_COOLER_BTN, gpio_isr_start_cooler_btn_handler, NULL);
}

void notify_temp_to_telegram(void * pvParameter){
 char telegram_msg[300];
  while (1){
    vTaskDelay(60000 / portTICK_PERIOD_MS);
    memset(telegram_msg,0,sizeof(telegram_msg));
    temp = read_temp();
    sprintf(telegram_msg, "Temp.: %.1f°C\nIntervalo de operação: %.1f a %.1f °C", temp, INF_LIM, SUP_LIM);
    xTaskCreatePinnedToCore(&http_test_task, "http_test_task", 8192*4, telegram_msg, 5, NULL,1);
  }
}

void app_main()
{ 

  esp_err_t ret = nvs_flash_init();
  if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    ESP_ERROR_CHECK(nvs_flash_erase());
    ret = nvs_flash_init();
  }
  ESP_ERROR_CHECK(ret);

  //Change it the pin that has a led
  gpio_pad_select_gpio(LED);
  gpio_set_direction(LED, GPIO_MODE_OUTPUT);
  gpio_set_level(LED, 1);

  printf("ESP_WIFI_MODE_STA");
  wifi_init_sta();
  vTaskDelay(2500 / portTICK_PERIOD_MS);

gpio_install_isr_service(0);

  config_temp_sensor();
  config_inc_sup_btn();
  config_dec_sup_btn();
  config_inc_inf_btn();
  config_dec_inf_btn();
  config_ok_temp_led();
  config_bad_temp_led();
  config_heating_led();
  config_cooling_led();
  config_cooler_en_pin();
  config_heater_en_pin();
  config_start_heater_btn();
  config_start_cooler_btn();



  setenv("TZ", "GMT+3", 1);
  tzset();

  sntp_setoperatingmode(SNTP_SYNC_MODE_IMMED);
  sntp_setservername(0, "pool.ntp.org");
  sntp_init();

    time_t hora_t;
  xTaskCreate(&config_ext_display, "config_ext_display_task", 4096, NULL, 5, NULL);
  vTaskDelay(100 / portTICK_PERIOD_MS);
  char saida_lcd_parte1[100];
  char saida_lcd_parte2[100];
  TaskHandle_t bad_temp_handle;

  xTaskCreate( &blink_bad_temp_led, "blink_bad_temp_led_task", 4096, NULL, 5, &bad_temp_handle );
  vTaskDelay(20 / portTICK_PERIOD_MS);
  vTaskSuspend( bad_temp_handle );
  gpio_set_level(BAD_TEMP_LED, 0);

  xTaskCreate( &blink_heating_led, "blink_heating_led_task", 4096, NULL, 5, &heating_led_handle );
  vTaskDelay(20 / portTICK_PERIOD_MS);
  vTaskSuspend( heating_led_handle );
  gpio_set_level(HEATING_LED, 0);

  xTaskCreate( &blink_cooling_led, "blink_cooling_led_task", 4096, NULL, 5, &cooling_led_handle );
  vTaskDelay(20 / portTICK_PERIOD_MS);
  vTaskSuspend( cooling_led_handle );
  gpio_set_level(COOLING_LED, 0);

  xTaskCreate( &notify_temp_to_telegram, "notify_temp_to_telegram_task", 4096, NULL, 5, &notify_temp_to_telegram_handle );

  heating = 0;
  cooling = 0;
  strcat(url_string, TOKEN_BOT);
  while (1) 
  { 
    temp = read_temp();
    if (!heating && !cooling){
      if (temp < INF_LIM){
        start_heater();
      } else if (temp > SUP_LIM) {
        start_cooler();
      }
    } else {
      gettimeofday(&tv_now, NULL);
      timeB = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
      if (timeB - timeA > (1000000 * 30)){
        if (heating){
          if (temp < INF_LIM){
            gettimeofday(&tv_now, NULL);
            timeA = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
          } else {
            stop_heater();
            
          }
        } else {
          if (temp > SUP_LIM) {
            gettimeofday(&tv_now, NULL);
            timeA = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
          } else {
            stop_cooler();
            
          }
        }
      }
    }
    if (temp >= INF_LIM && temp <= SUP_LIM){
      gpio_set_level(TEMP_OK_LED, 1);
      vTaskSuspend( bad_temp_handle );
      gpio_set_level(BAD_TEMP_LED, 0);
    } else {
      gpio_set_level(TEMP_OK_LED, 0);
      vTaskResume( bad_temp_handle );
    }
    memset(saida_lcd_parte1,0,sizeof(saida_lcd_parte1));
    sprintf(saida_lcd_parte1, "Temp.: %.1f C", temp);
    for (int len = strlen(saida_lcd_parte1); len < 16; len++){
      strcat(saida_lcd_parte1, " ");
    }
    write_on_display(saida_lcd_parte1, 0);
    memset(saida_lcd_parte2,0,sizeof(saida_lcd_parte2));
    sprintf(saida_lcd_parte2, "%.1f a %.1f C", INF_LIM, SUP_LIM);
    for (int len = strlen(saida_lcd_parte2); len < 16; len++){
      strcat(saida_lcd_parte2, " ");
    }
    write_on_display(saida_lcd_parte2, 1);
    //printf("%s\n", saida_lcd_parte1);
    //printf("%s\n", saida_lcd_parte2);
    //printf("\n");
    vTaskDelay(500 / portTICK_PERIOD_MS);
  }
}